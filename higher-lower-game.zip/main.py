#Higher/Lower

#import clear
from replit import clear

#import data
from game_data import data

#import random
import random

#import art: logo and VS
from art import logo, vs

def generate(list):
  """Generates random number that hasnt been selected"""
  chosen_num = random.randint(0,49)
  if chosen_num not in list:
    list.append(chosen_num)
    return chosen_num
  else:
    return generate(chosen_list)

def pick(info):
  """puts info in list format and returns it"""
  list = []
  for key in info:
    if key != "follower_count":
      list.append(info[key])   
  return list

def compare(pick_1, pick_2):
  """compares the two options and returns A or B depending on who has larger follower_count"""
  if pick_1["follower_count"] > pick_2["follower_count"]:
    return "A"   #A means pick_1 greater than pick_2
  elif pick_1["follower_count"] < pick_2["follower_count"]:
    return "B"   #B means pick_2 greater than pick_1


def game(A, B, list, score):
  """Higher or Lower game"""
  list_A = pick(A)
  list_B = pick(B)

  print(f"compare A: {list_A[0]}, a {list_A[1]}, from {list_A[2]}")
  print(vs)
  print(f"compare B: {list_B[0]}, a {list_B[1]}, from {list_B[2]}")
  
  user_guess = input("Who has more followers? Type 'A' or 'B': ").upper()
  correct_answer = compare(A, B)
  clear()
  print(logo)
  if len(list) == 50 and user_guess == correct_answer:
    print(f"You win HOLY!!!!!. CONGRATULATIONS.")
    return
  elif user_guess == correct_answer:
    score += 1
    print(f"Correct. Your score is: {score}")
    A = B
    B = data[generate(list)]
    return game(A, B, list, score)
  
  else:
    print(f"Incorrect your total score was: {score}")
    return
  print(user_guess)
  print(correct_answer)
  print(chosen_list)


chosen_list = []
score = 0

data_A = generate(chosen_list)
data_B = generate(chosen_list)

pick_A = data[data_A]
pick_B = data[data_B]

print(logo)

game(pick_A, pick_B, chosen_list, score)